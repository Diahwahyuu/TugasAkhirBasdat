/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klinik_tht;

/**
 *
 * @author victus joe
 */
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class Coba extends JFrame {
    private JComboBox<String> doctorComboBox;
    private JComboBox<String> scheduleComboBox;

    // Struktur data untuk memetakan dokter dengan jadwal
    private HashMap<String, String[]> doctorSchedules;

    public Coba() {
        setTitle("Doctor Appointment");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Data dummy dokter dan jadwal
        doctorSchedules = new HashMap<>();
        doctorSchedules.put("Dr. John", new String[]{"Senin 10:00-12:00", "Rabu 14:00-16:00"});
        doctorSchedules.put("Dr. Sarah", new String[]{"Selasa 09:00-11:00", "Kamis 13:00-15:00"});

        doctorComboBox = new JComboBox<>(doctorSchedules.keySet().toArray(new String[0]));
        scheduleComboBox = new JComboBox<>();

        doctorComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedDoctor = (String) doctorComboBox.getSelectedItem();
                if (selectedDoctor != null) {
                    String[] schedules = doctorSchedules.get(selectedDoctor);
                    if (schedules != null) {
                        scheduleComboBox.removeAllItems();
                        for (String schedule : schedules) {
                            scheduleComboBox.addItem(schedule);
                        }
                    }
                }
            }
        });

        JPanel panel = new JPanel();
        panel.add(new JLabel("Nama Dokter: "));
        panel.add(doctorComboBox);
        panel.add(new JLabel("Jadwal Dokter: "));
        panel.add(scheduleComboBox);
        add(panel);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Coba appointment = new Coba();
                appointment.setVisible(true);
            }
        });
    }
}

