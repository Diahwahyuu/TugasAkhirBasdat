/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package klinik_tht;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Percobaan {
    static String url = "jdbc:sqlserver://localhost\\SQLEXPRESS:1433;databaseName=UTP_045;encrypt=true;trustServerCertificate=true";
    static String username = "Ocin";
    static String password = "aryanico";
    
    public static void main(String[] args) {
        ResultSet resultSet = null;
        try (Connection connection = DriverManager.getConnection(url, username, password);
                Statement statement = connection.createStatement();) {
            String querySelect = "select top 5 id, name, dept_name from instructor_045";
            resultSet = statement.executeQuery(querySelect);
            
            while (resultSet.next()) {
                System.out.println(resultSet.getString(2) + " (" + resultSet.getString(3) + ")");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
